package com.sapfee.calc.controller;

import com.sapfee.calc.model.Transaction;
import com.sapfee.calc.service.TransactionService;
import com.sapfee.calc.utils.AppUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/dashboard")
public class TransactionController {

    private Map<String,TransactionService> transactionServices;

    public TransactionController(Map<String,TransactionService> transactionServices){
        System.out.println("Controllers : " +  transactionServices);
        this.transactionServices = transactionServices;
    }

    @RequestMapping("/showForm")
    public String showForm(Model model){
        return "dashboard";
    }

    @RequestMapping(method= RequestMethod.POST,value="/upload")
    public String uploadFile(@RequestParam("file")MultipartFile file, RedirectAttributes redirectAttributes,Model model){
        if(!file.isEmpty() && AppUtils.isValidFileExtension(file.getResource().getFilename())){
           System.out.println(file.getResource().getFilename());
            TransactionService transactionService = findTransactionService(file.getResource().getFilename());
            List<Transaction> transactions = transactionService.getTransactions(file);
            List<Transaction> processedTransactions = transactionService.processTransactions(transactions);
            System.out.println("ProcessedTransactions :" + processedTransactions);
            model.addAttribute("records", processedTransactions);
        }
        return "success";
    }

  private TransactionService findTransactionService(String filename) {
    if (AppUtils.isCSVFile(filename)) {
      return transactionServices.get(AppUtils.CSV);
    } else if (AppUtils.isExcelFile(filename)) {
      return transactionServices.get(AppUtils.EXCEL);
    } else if (AppUtils.isTXTFile(filename)) {
      return transactionServices.get(AppUtils.TXT);
    } else if (AppUtils.isXMLFile(filename)) {
      return transactionServices.get(AppUtils.XML);
    } else {
      return null;
    }
  }
}
