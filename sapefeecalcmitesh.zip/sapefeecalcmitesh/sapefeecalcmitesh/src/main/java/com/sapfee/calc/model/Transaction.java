package com.sapfee.calc.model;


import java.math.BigDecimal;

/** Transaction Model Object */

public class Transaction {

  private String externalTransactionId;
  private String clientId;
  private String securityId;
  private String transactionType;
  private String transactionDate;
  private String marketValue;
  private String priorityFlag;
  private Double fees;

  public Double getFees() {
    return fees;
  }

  public void setFees(Double fees) {
    this.fees = fees;
  }

  public String getExternalTransactionId() {
    return externalTransactionId;
  }

  public void setExternalTransactionId(String externalTransactionId) {
    this.externalTransactionId = externalTransactionId;
  }

  public String getClientId() {
    return clientId;
  }

  public void setClientId(String clientId) {
    this.clientId = clientId;
  }

  public String getSecurityId() {
    return securityId;
  }

  public void setSecurityId(String securityId) {
    this.securityId = securityId;
  }

  public String getTransactionType() {
    return transactionType;
  }

  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType;
  }

  public String getTransactionDate() {
    return transactionDate;
  }

  public void setTransactionDate(String transactionDate) {
    this.transactionDate = transactionDate;
  }

  public String getMarketValue() {
    return marketValue;
  }

  public void setMarketValue(String marketValue) {
    this.marketValue = marketValue;
  }

  public String getPriorityFlag() {
    return priorityFlag;
  }

  public void setPriorityFlag(String priorityFlag) {
    this.priorityFlag = priorityFlag;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    Transaction that = (Transaction) o;

    if (externalTransactionId != null
        ? !externalTransactionId.equals(that.externalTransactionId)
        : that.externalTransactionId != null) return false;
    if (clientId != null ? !clientId.equals(that.clientId) : that.clientId != null) return false;
    if (securityId != null ? !securityId.equals(that.securityId) : that.securityId != null)
      return false;
    if (transactionType != null
        ? !transactionType.equals(that.transactionType)
        : that.transactionType != null) return false;
    if (transactionDate != null
        ? !transactionDate.equals(that.transactionDate)
        : that.transactionDate != null) return false;
    if (marketValue != null ? !marketValue.equals(that.marketValue) : that.marketValue != null)
      return false;
    return priorityFlag != null
        ? priorityFlag.equals(that.priorityFlag)
        : that.priorityFlag == null;
  }

  @Override
  public int hashCode() {
    int result = externalTransactionId != null ? externalTransactionId.hashCode() : 0;
    result = 31 * result + (clientId != null ? clientId.hashCode() : 0);
    result = 31 * result + (securityId != null ? securityId.hashCode() : 0);
    result = 31 * result + (transactionType != null ? transactionType.hashCode() : 0);
    result = 31 * result + (transactionDate != null ? transactionDate.hashCode() : 0);
    result = 31 * result + (marketValue != null ? marketValue.hashCode() : 0);
    result = 31 * result + (priorityFlag != null ? priorityFlag.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("Transaction{");
    sb.append("externalTransactionId='").append(externalTransactionId).append('\'');
    sb.append(", clientId='").append(clientId).append('\'');
    sb.append(", securityId='").append(securityId).append('\'');
    sb.append(", transactionType='").append(transactionType).append('\'');
    sb.append(", transactionDate='").append(transactionDate).append('\'');
    sb.append(", marketValue='").append(marketValue).append('\'');
    sb.append(", priorityFlag='").append(priorityFlag).append('\'');
    sb.append(", fees=").append(fees);
    sb.append('}');
    return sb.toString();
  }
}
