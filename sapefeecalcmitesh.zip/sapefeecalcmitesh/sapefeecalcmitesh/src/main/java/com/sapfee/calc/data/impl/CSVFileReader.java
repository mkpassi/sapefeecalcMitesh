package com.sapfee.calc.data.impl;

import com.sapfee.calc.data.FileReader;
import com.sapfee.calc.model.Transaction;
import com.sapfee.calc.utils.AppUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class CSVFileReader implements FileReader {

  @Override
  public List<Transaction> readFile(MultipartFile file) {
    List<String> result = new ArrayList<>();
    String line;
    List<Transaction> transactionList = new ArrayList<>();
    try {
      System.out.println("Content type : " + file.getContentType());
      BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()));
      while ((line = reader.readLine()) != null) {
        result.add(line);
      }
      List<String> data = result.stream().skip(1).collect(Collectors.toList());
      System.out.println(data);

      transactionList =
          data.stream()
              .map(
                  record -> {
                    Transaction transaction = new Transaction();
                    if (AppUtils.isNotEqualsOrEmpty(record)) {
                      String[] tuple = record.split(AppUtils.COMMA);
                      transaction.setExternalTransactionId(tuple[0]);
                      transaction.setClientId(tuple[1]);
                      transaction.setSecurityId(tuple[2]);
                      transaction.setTransactionType(tuple[3]);
                      transaction.setTransactionDate(tuple[4]);
                      transaction.setMarketValue(tuple[5]);
                      transaction.setPriorityFlag(tuple[6]);
                    }
                    return transaction;
                  })
              .collect(Collectors.toList());
    } catch (IOException e) {
      System.err.println(e.getMessage());
    }
    System.out.println("TransactionList: " + transactionList);
    return transactionList;
  }
}
