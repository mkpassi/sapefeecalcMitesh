package com.sapfee.calc.data;

import com.sapfee.calc.model.Transaction;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;

public interface FileReader {
  List<Transaction> readFile(MultipartFile file);

}
