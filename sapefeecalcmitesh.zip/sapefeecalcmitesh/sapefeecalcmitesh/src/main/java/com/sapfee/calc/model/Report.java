package com.sapfee.calc.model;

/**
 * Report Model Object
 */
public class Report {

    private String clientId;
    private String transactionType;
    private String transactionDate;
    private String priority;
    private String processingFee;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getProcessingFee() {
        return processingFee;
    }

    public void setProcessingFee(String processingFee) {
        this.processingFee = processingFee;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Report report = (Report) o;

        if (clientId != null ? !clientId.equals(report.clientId) : report.clientId != null) return false;
        if (transactionType != null ? !transactionType.equals(report.transactionType) : report.transactionType != null)
            return false;
        if (transactionDate != null ? !transactionDate.equals(report.transactionDate) : report.transactionDate != null)
            return false;
        if (priority != null ? !priority.equals(report.priority) : report.priority != null) return false;
        return processingFee != null ? processingFee.equals(report.processingFee) : report.processingFee == null;
    }

    @Override
    public int hashCode() {
        int result = clientId != null ? clientId.hashCode() : 0;
        result = 31 * result + (transactionType != null ? transactionType.hashCode() : 0);
        result = 31 * result + (transactionDate != null ? transactionDate.hashCode() : 0);
        result = 31 * result + (priority != null ? priority.hashCode() : 0);
        result = 31 * result + (processingFee != null ? processingFee.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Report{");
        sb.append("clientId='").append(clientId).append('\'');
        sb.append(", transactionType='").append(transactionType).append('\'');
        sb.append(", transactionDate='").append(transactionDate).append('\'');
        sb.append(", priority='").append(priority).append('\'');
        sb.append(", processingFee='").append(processingFee).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
