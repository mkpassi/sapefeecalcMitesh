package com.sapfee.calc.service;

import com.sapfee.calc.data.FileReader;
import com.sapfee.calc.model.Transaction;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;

public interface TransactionService {

    public List<Transaction> getTransactions(MultipartFile file);
    public List<Transaction> processTransactions(List<Transaction> tranasactions);
    public String getName();


}
