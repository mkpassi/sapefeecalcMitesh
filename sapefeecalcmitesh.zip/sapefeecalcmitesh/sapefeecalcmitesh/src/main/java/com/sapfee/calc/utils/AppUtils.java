package com.sapfee.calc.utils;

public class AppUtils {

  public static final String CSV = "CSVTransactionService";
  public static final String EXCEL = "EXCELTransactionService";
  public static final String TXT = "textTransactionService";
  public static final String XML = "XMLTransactionService";
  public static final String COMMA = ",";
  public static final String BUY = "BUY";
  public static final String SELL = "SELL";
  public static final String DEPOSIT = "DEPOSIT";
  public static final String WITHDRAW = "WITHDRAW";
  public static final String Y_STRING = "Y";
  public static final String N_STRING = "Y";
  public static final Double TEN_DOLLAR = 10.00;
  public static final Double FIVE_HUNDRED_DOLLARS = 500.00;
  public static final Double HUNDRED_DOLLARS = 100.00;
  public static final Double FIFTY_DOLLARS = 50.00;
  private static final String CSV_SUFFIX_EXTENSION = ".csv";
  private static final String EXCEL_SUFFIX_EXTENSION = ".xls";
  private static final String XML_SUFFIX_EXTENSION = ".xml";
  private static final String TXT_SUFFIX_EXTENSION = ".txt";

  public static boolean isNotEqualsOrEmpty(String str) {
    return str != null && !str.isEmpty();
  }

  public static boolean isValidFileExtension(String fileName) {
       return isCSVFile(fileName) || isXMLFile(fileName) || isTXTFile(fileName) || isExcelFile(fileName);
  }

  public static boolean isCSVFile(String fileName){
      return fileName.endsWith(CSV_SUFFIX_EXTENSION);
  }

  public static boolean isExcelFile(String fileName){
     return fileName.endsWith(EXCEL_SUFFIX_EXTENSION);
  }

  public static boolean isTXTFile(String fileName){
      return fileName.endsWith(TXT_SUFFIX_EXTENSION);
  }

  public static boolean isXMLFile(String fileName){
      return fileName.endsWith(XML_SUFFIX_EXTENSION);
  }
}
