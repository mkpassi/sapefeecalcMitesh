package com.sapfee.calc;

import com.sapfee.calc.service.TransactionService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SpringBootApplication
public class SapeFeeCalcMiteshApplication {

  public static void main(String[] args) {
    SpringApplication.run(SapeFeeCalcMiteshApplication.class, args);
  }

  @Bean
  Map<String, TransactionService> transactionServices(
      List<TransactionService> transactionServices) {
   // System.out.println("List of TransactionServices" + transactionServices);
  	Map<String, TransactionService> transactionStrategy = new HashMap<>();
    transactionServices.forEach(
        transactionService ->
            transactionStrategy.put(transactionService.getName(), transactionService));
    return transactionStrategy;
  }
}
