package com.sapfee.calc.service.impl;

import com.sapfee.calc.data.FileReader;
import com.sapfee.calc.model.Transaction;
import com.sapfee.calc.service.TransactionService;
import com.sapfee.calc.utils.AppUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;

@Service
public class CSVTransactionService implements TransactionService {

  @Qualifier("CSVFileReader")
  @Autowired
  FileReader fileReader;

  @Override
  public List<Transaction> getTransactions(MultipartFile file) {
    return fileReader.readFile(file);
  }

  @Override
  public List<Transaction> processTransactions(List<Transaction> tranasactions) {
        tranasactions.forEach(transaction -> {
            if(isIntraDayTransaction(transaction,tranasactions)){
                transaction.setFees(AppUtils.TEN_DOLLAR);
            }else{
                if(transaction.getPriorityFlag().equals(AppUtils.Y_STRING)){
                    transaction.setFees(AppUtils.FIVE_HUNDRED_DOLLARS);
                }else{
                    if((transaction.getTransactionType().equals(AppUtils.SELL)) || (transaction.getTransactionType().equals(AppUtils.WITHDRAW))){
                        transaction.setFees(AppUtils.HUNDRED_DOLLARS);
                    }else if((transaction.getTransactionType().equals(AppUtils.BUY)) || (transaction.getTransactionType().equals(AppUtils.DEPOSIT))){
                        transaction.setFees(AppUtils.FIFTY_DOLLARS);
                    }
                }
            }
        });
      return tranasactions;
  }

    private boolean isIntraDayTransaction(Transaction transaction, List<Transaction> transactionList) {
       boolean isIntraDayTx = Boolean.FALSE;
        for (Transaction transactionRecord : transactionList) {
            if (transaction != transactionRecord) {
                if ((transaction.getClientId().equals(transactionRecord.getClientId()))
                        && (transaction.getSecurityId().equals(transactionRecord.getSecurityId()))
                        && transaction
                        .getTransactionDate()
                        .equals(transactionRecord.getTransactionDate())) {

                    if ((transaction.getTransactionType().equals(AppUtils.BUY) && transactionRecord.getTransactionType().equals(AppUtils.SELL)) ||
                    (transaction.getTransactionType().equals(AppUtils.SELL) && transactionRecord.getTransactionType().equals(AppUtils.BUY))) {
                        isIntraDayTx = Boolean.TRUE;
                        break;
                    }
                }
            }
        }
        return isIntraDayTx;
    }

    @Override
  public String getName() {
    return AppUtils.CSV;
  }
}
