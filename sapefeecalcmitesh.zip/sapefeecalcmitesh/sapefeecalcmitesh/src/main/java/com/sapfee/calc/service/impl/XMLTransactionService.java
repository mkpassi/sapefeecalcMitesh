package com.sapfee.calc.service.impl;

import com.sapfee.calc.data.FileReader;
import com.sapfee.calc.model.Transaction;
import com.sapfee.calc.service.TransactionService;
import com.sapfee.calc.utils.AppUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;

@Service
public class XMLTransactionService implements TransactionService {
  @Override
  public List<Transaction> getTransactions(MultipartFile file) {
    return null;
  }

  @Override
  public List<Transaction> processTransactions(List<Transaction> tranasactions) {
    return null;
  }

  @Override
  public String getName() {
    return AppUtils.XML;
  }
}
