package com.sapfee.calc.data.impl;

import com.sapfee.calc.data.FileReader;
import com.sapfee.calc.model.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;

@Component
public class PipedDelimiterFileReader implements FileReader {

    private List<Transaction> allTransactions;

    @Override
    public List<Transaction> readFile(MultipartFile file) {
        return allTransactions;
    }


}
