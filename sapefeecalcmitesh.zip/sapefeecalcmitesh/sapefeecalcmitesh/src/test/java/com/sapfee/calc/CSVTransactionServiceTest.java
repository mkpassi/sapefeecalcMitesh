package com.sapfee.calc;

import com.sapfee.calc.service.impl.CSVTransactionService;
import com.sapfee.calc.utils.AppUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
public class CSVTransactionServiceTest {

    @TestConfiguration
    static class CSVServiceTextConfigurationBean{

        @Bean
        public CSVTransactionService csvService(){
            return new CSVTransactionService();
        }

    }

    @Autowired CSVTransactionService csvTransactionService;

    @Test
    public void TestFileName(){
        assertThat(AppUtils.CSV).isEqualTo(csvTransactionService.getName());
    }

    @Test
    //TEst Case by passing a sample trnasaction List and check for Result
    public void TestProcessTransaction(){
        csvTransactionService.processTransactions(new ArrayList<>());
    }

    @Test
    //Test Case for File Upload, passing a Mocked Multipart File and verify for Output
    public void FileUploadTest(){
    }

}
