package com.sapfee.calc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SapeFeeCalcMiteshApplicationTests {

	@Test
	void contextLoads() {
	}

}
